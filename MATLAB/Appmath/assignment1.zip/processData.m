load('experimentData');
EDHR = experimentData(:,1);
EDWt = experimentData(:,2);
EDex = experimentData(:,3);
[HRmean, HRSEM] = meanSEM(EDHR);
[Wtmean, WtSEM] = meanSEM(EDWt);
[excermean, excerSEM] = meanSEM(EDex);

figure(1);

subplot(3,1,1);
plot(EDHR,'o-');
hold on;
plot(HRmean*ones(size(EDHR)));
hold on;
plot(HRmean+HRSEM*ones(size(EDHR)),'linestyle','--');
hold on;
plot(HRmean-HRSEM*ones(size(EDHR)),'linestyle','--');
title('Heartrate mean & SEM')
xlabel('Participant number')
ylabel('Heart Rate')

subplot(3,1,2);
plot(EDWt,'o-');
hold on;
plot(Wtmean*ones(size(EDWt)));
hold on;
plot(Wtmean+WtSEM*ones(size(EDWt)),'linestyle','--');
hold on;
SE1 = plot(Wtmean-WtSEM*ones(size(EDWt)),'linestyle','--');
title('Weight mean & SEM')
xlabel('Participant number')
ylabel('Weight(Kg)')


subplot(3,1,3)

plot(EDex,'o-');
hold on;
plot(excermean*ones(size(EDex)));
hold on;
plot(excermean+excerSEM*ones(size(EDex)),'linestyle','--');
hold on;
plot(excermean-excerSEM*ones(size(EDHR)),'linestyle','--');
title('Exercise mean & SEM')
xlabel('Participant number')
ylabel('Excercise')

saveas(gcf,'analysis.fig');

figure(2);
subplot(3,1,1)
scatter(EDHR,EDWt);
polyfit(EDHR,EDWt,1)
title('Heartrate& Weight')
xlabel('Heartrate')
ylabel('Weight')

subplot(3,1,2)
scatter(EDHR,EDex);
polyfit(EDHR,EDex,1)
title('Heartrate & Excercise')
xlabel('Heartrate')
ylabel('Excercise')

subplot(3,1,3)
scatter(EDWt,EDex);
polyfit(EDWt,EDex,1)
title('Weight & Exercise')
xlabel('Weight')
ylabel('Excercise')
[R,P] = corrcoef(EDWt.EDex)
saveas(gcf,'analysis2.fig');
function lifesecs = yyyymmdd(bday)
bday = num2str(bday); 
byear = str2double(bday(1:4));
bmonth = str2double(bday(5:6));
bdate = str2double(bday(7:8));
currenttime = clock;
dayarray = [31 28 31 30 31 30 31 31 30 31 30 31 31 28 31 30 31 30 31 31 30 31 30 31];
year = currenttime(1)-1;
month = currenttime(2);
day = currenttime(3)-1;
sec = currenttime(4:6) * [3600; 60; 1];
lifesecs = (((year-byear)*365)+(sum(dayarray(bmonth+1:11+month-bmonth)))+ day)*86400 + sec;
return

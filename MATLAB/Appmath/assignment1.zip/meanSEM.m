function [meanout, SEMout] = meanSEM(targetdata)
meanout = mean(targetdata);
SEMout = std(targetdata)./sqrt(length(targetdata)-1);
return
